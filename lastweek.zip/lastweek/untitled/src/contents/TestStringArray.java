package contents;
import exceptions.InputMismatch;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TestStringArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ReadOnlyStringArray nc = new ReadOnlyStringArray("name","ian","welcome","name","help","helo");

        int input =0;
        while(input != -1){
            System.out.println("which index do you want to call from");
            try{
                input = sc.nextInt();
                System.out.println(nc.get(input));
            }catch(InputMismatchException e){
                System.out.println("not an integer");

            }catch(ArrayIndexOutOfBoundsException e){
                System.out.println("out of bound ");
            }
            catch(Exception e){
                System.out.println("well well have you learnt your lesson "
                        );
            }

        }
    }
}
