package contents;
import java.util.Scanner;
public class TestCircle {
    public static void main(String[] args) {
        Circle c = new Circle();
        Scanner dc = new Scanner(System.in);
        System.out.println("What is the radius:");
        try{
            c.setRadius(dc.nextInt())
            ;
        }catch(IllegalArgumentException e){
            throw e;
        }else{

            System.out.println(c.getRadius());
        }
    }
}
