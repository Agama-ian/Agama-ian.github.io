package contents;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Sam Scott
 */
public class ArrayListHandoutCode {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        ArrayList<String> a;        // declare

        a = new ArrayList<>();      // create

        System.out.println(a.size());

        System.out.println("Enter 5 strings");
        for (int i = 0; i < 5; i++) {
            a.add(sc.nextLine());
        }

        System.out.println("You entered:");
        for (String e : a) {
            System.out.println(e);
        }

        System.out.println("a.get(2)=" + a.get(2));

        // Example start list: apl cobol java ada java
        a.add(1, "pascal");
        a.add("basic");
        // Example final list: apl pascal cobol ada java basic

        System.out.println("Here they are after adding stuff");
        for (String e : a) {
            System.out.println(e);
        }

        System.out.println("Autoboxing test");

        ArrayList<Integer> b = new ArrayList<>();

        b.add(3);           // autoboxes 3 using new Integer(3);
        b.add(-5);
        b.add(33);
        b.add(10);

        int sum = 0;
        for (Integer e : b) {
            sum += e;       // unboxes e using e.intValue()
        }
        System.out.println(sum);

    }
}
