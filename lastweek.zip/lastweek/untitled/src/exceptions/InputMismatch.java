package exceptions;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 * exceptions in java is an unexpected or unwanted event
 * we want t
 */
public class InputMismatch {

    public static void main(String[] args) {//throws InterruptedException {
        int num;

        Scanner sc = new Scanner(System.in);
        System.out.println("Please enter an integer:");

        //stack trace is a path and is shown in the terminal about the program subroutines
        //errors come and are shown by the blue highlight
        //exceptions are then used to try and catch the errors and identify the areas that are missing
        //get the errors and this could be vey interesting while correcting a very specific area of the code
        //interrupted exception cannot be interrupted by any java
        //how t fix it
        //try/catch note:
        //if you use try/catch
        //declare it in class header
        //checked exceptions are given to errors that inherit directly from the exception class
        //there are 2 ie FileNotFound and Interrupted (blue or red line)
        //unchecked exceptions ie INputMismatch, IllegalArgument, Arithmetic , NUmber format
        // these extend Runtime exceptions

        //use catch(Exception e)=
        try{
            num = sc.nextInt();
        }catch (InputMismatchException e){//this will onl appear if the code above didnt provide the required parameters
            System.out.println("why didn't you add an integer!!! ");

//            e.printStackTrace();//prints out the stack trace
            //Thread.sleep(1000);
//            System.out.println(e.getMessage());//this identifies the error in the code
        }
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println("Thank you");
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
//        System.out.println(" you!");
//        for(int i=0; i < num; num++){
//            try {
//                Thread.sleep(1000);
//            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
//            }
//            System.out.println(" you!"+ i);
//        }
    }
}
