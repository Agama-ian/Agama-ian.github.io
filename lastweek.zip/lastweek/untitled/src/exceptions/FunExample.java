package exceptions;
import java.util.InputMismatchException;
import java.util.Scanner;
public class FunExample {
    public static void main(String[] args) {
        Scanner tc = new Scanner(System.in);
        int delay =0;
        while(true){
            try{
                delay = tc.nextInt();
                Thread.sleep(delay);
                System.out.println("delay in mins is "+delay+"delay inverse"+1/delay);
                //arithmetic errror can be fixed by catch to et the

            }catch(InterruptedException e){
                System.out.println("caught interrupted excption:");

            }catch(InputMismatchException e){
                System.out.println("bad input"+ tc.next());
            }catch(ArithmeticException e){
                System.out.println("Zero has no inverse  "+ e.getMessage());
            }catch(IllegalArgumentException e){
                System.out.printf(e.getMessage());
            }catch(Exception e){
                System.out.println(e.getMessage( ));
            }
        }



    }

}
